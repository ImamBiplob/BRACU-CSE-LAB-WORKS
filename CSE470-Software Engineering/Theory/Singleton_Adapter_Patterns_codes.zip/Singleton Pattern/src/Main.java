class Client {
    // HelpDesk helpDesk;
    HelpDeskSingleton helpDesk;

    public Client() {
        // helpDesk = new HelpDesk();
        // helpDesk = new HelpDeskSingleton();
         helpDesk = HelpDeskSingleton.getInstance();
    }

    public void getService() {
        helpDesk.getService();
    }
}

public class Main {
    public static void main(String[] args) {

        Client client1 = new Client();
        Client client2 = new Client();

        client1.getService();
        client2.getService();
    }
}
