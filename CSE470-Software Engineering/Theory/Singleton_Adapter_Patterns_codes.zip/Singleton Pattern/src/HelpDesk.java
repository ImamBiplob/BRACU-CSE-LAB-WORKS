public class HelpDesk {
    static int counter = 0;
    int helpDeskID;

    public HelpDesk() {
        counter += 1;
        helpDeskID = counter;
    }

    public void getService() {
        System.out.println("Help provided from helpdesk " + helpDeskID);
    }
}
