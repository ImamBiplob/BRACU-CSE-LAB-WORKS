public class HelpDeskSingleton {
    static int counter = 0;
    int helpDeskID;
    static HelpDeskSingleton helpDeskInstance;

    private HelpDeskSingleton() {
        counter += 1;
        helpDeskID = counter;
    }

    public static HelpDeskSingleton getInstance() {
        if(helpDeskInstance == null) {
            helpDeskInstance = new HelpDeskSingleton();
        }
        return helpDeskInstance;
    }

    public void getService() {
        System.out.println("Help provided from helpdesk " + helpDeskID);
    }
}
