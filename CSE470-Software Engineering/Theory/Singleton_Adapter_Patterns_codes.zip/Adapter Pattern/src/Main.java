import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Pizza> pizzas = new ArrayList<>();

        pizzas.add(new DhakaPizza());

        // pizzas.add(new CtgPizza());

         pizzas.add(new CtgPizzaClassAdapter());
         pizzas.add(new CtgPizzaObjectAdapter(/*false*/));

         pizzas.add(new CtgPizzaObjectAdapter(true));

        for(Pizza p: pizzas) {
            p.toppings();
            p.buns();
            // p.serve();
            System.out.println("Pizza done!\n");
        }
    }
}
