class CtgPizzaClassAdapter extends CtgPizza implements Pizza {

    public CtgPizzaClassAdapter() {
        super();
    }

    @Override
    public void toppings() {
        sausage();
    }

    @Override
    public void buns() {
        bread();
    }


    @Override
    public void sausage() {
        System.out.println("Overfried sausages added for Ctg Pizza.");
    }


}

class CtgPizzaObjectAdapter implements Pizza {
    private CtgPizza ctgPizza;

    public CtgPizzaObjectAdapter() {
        ctgPizza = new CtgPizza();
    }

    @Override
    public void toppings() {
        ctgPizza.sausage();
    }

    public void buns() {
        ctgPizza.bread();
    }


    public CtgPizzaObjectAdapter(boolean soft) {
        if(soft)
            ctgPizza = new CtgPizzaSoft();
        else {
            ctgPizza = new CtgPizza();
        }
    }

}