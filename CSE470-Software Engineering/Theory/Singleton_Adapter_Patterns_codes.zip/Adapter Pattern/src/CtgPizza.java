class CtgPizza /*implements Pizza*/ {
    public void sausage(){
        System.out.println("Sausages added for Ctg pizza");
    }
    public void bread(){
        System.out.println("Thick crust for Ctg pizza");
    }
}

class CtgPizzaSoft extends CtgPizza {
    @Override
    public void bread() {
        System.out.println("Thick but soft crust for Ctg pizza");
    }
}



