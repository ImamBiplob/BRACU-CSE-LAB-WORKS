public interface Pizza {

    abstract void toppings();
    abstract void buns();
}

class DhakaPizza implements Pizza {
    @Override
    public void toppings() {
        System.out.println("Mozzarella cheese toppings for Dhaka pizza");
    }

    @Override
    public void buns() {
        System.out.println("Medium crust buns for Dhaka pizza");
    }

    public void serve() {
        System.out.println("Serving pizza to customer");
    }
}

