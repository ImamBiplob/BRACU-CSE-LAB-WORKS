import java.util.ArrayList;

public class Celebrity {
    String name;
    ArrayList<Fan> fanList = new ArrayList<>();

    public Celebrity(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void add(Fan fan) {
        fanList.add(fan);
    }
    public void remove(Fan fan) {
        fanList.remove(fan);
    }

    public void notifyFans(String[] message) {
        for(Fan fan: fanList)
            fan.notify(this, message);
    }

    void uploadVideo(String videoName) {
        String[] message = {"video upload", videoName};
        notifyFans(message);
    }

    void changeDp() {
        String[] message = {"dp update"};
        notifyFans(message);
    }
}
