public class Main {
    public static void main(String[] args) {

        Celebrity shahrukh = new Celebrity("Shahrukh Khan");
        Celebrity katrina = new Celebrity("Katrina Kaif");

        CasualFan sumon = new CasualFan("Sumon");
        DieHardFan nipu = new DieHardFan("Nipu");

        sumon.follow(shahrukh);
        nipu.follow(shahrukh);

        System.out.println("-> Shahrukh uploads new video\n");
        shahrukh.uploadVideo("New hit song");

        System.out.println("-> Katrina changes dp\n");
        katrina.changeDp();

        sumon.follow(katrina);
        nipu.follow(katrina);

        System.out.println("-> Katrina changes dp\n");
        katrina.changeDp();

        nipu.showAllCelebs();

        nipu.unfollow(katrina);

        System.out.println("-> Katrina uploads new video\n");
        katrina.uploadVideo("New song");
    }
}
