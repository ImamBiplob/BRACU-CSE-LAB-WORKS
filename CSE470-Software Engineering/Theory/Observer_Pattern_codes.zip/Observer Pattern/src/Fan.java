import java.util.ArrayList;

public abstract class Fan {
    String name;

    public Fan(String name) {
        this.name = name;
    }

    void follow(Celebrity celeb) {
        celeb.add(this);
    }

    void unfollow(Celebrity celeb) {
        celeb.remove(this);
    }

    abstract void notify(Celebrity celeb, String[] message);
}

class CasualFan extends Fan {
    public CasualFan(String name) {
        super(name);
    }

    @Override
    public void notify(Celebrity celeb, String[] message) {
        if(message.length == 0)
            return;

        if(message[0].equals("video upload")) {
            System.out.println("Notification for " + name + ":");
            System.out.println("New video uploaded by " + celeb.getName() + "\n");
        }
    }
}

class DieHardFan extends Fan {
    ArrayList<Celebrity> celebList = new ArrayList<>();

    public DieHardFan(String name) {
        super(name);
    }

    @Override
    public void follow(Celebrity celeb) {
        super.follow(celeb);
        celebList.add(celeb);
    }

    @Override
    public void unfollow(Celebrity celeb) {
        super.unfollow(celeb);
        celebList.remove(celeb);
    }

    @Override
    public void notify(Celebrity celeb, String[] message) {
        if(message.length == 0)
            return;

        if(message[0].equals("video upload")) {
            System.out.println("Notification for " + name + ":");
            System.out.println("New video uploaded by " + celeb.getName() + ": \"" + message[1] + "\"" + "\n");
        }

        else if(message[0].equals("dp update")) {
            System.out.println("Notification for " + name + ":");
            System.out.println("dp changed by " + celeb.getName() + "\n");
        }
    }

    void showAllCelebs() {
        System.out.println("Celebs followed by " + name + ": ");

        for(Celebrity celeb: celebList)
            System.out.print("\"" + celeb.getName() + "\" ");

        System.out.println();
    }
}
