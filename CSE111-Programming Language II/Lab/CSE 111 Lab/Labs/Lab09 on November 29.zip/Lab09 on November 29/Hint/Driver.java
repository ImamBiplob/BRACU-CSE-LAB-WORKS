public class Driver
{
  public static void main(String[] args)
  {
    Scope q2 = new Scope();
q2.met1();
int answer1=q2.met2();
q2.met1();
int answer2=q2.met2();

  }
}