public class Test{
  public static void main(String [] args){
  FinalT6A q1 = new FinalT6A(2,1);
q1.methodA();
FinalT6A q2 = new FinalT6A(4,5);
q2.methodA();

  }
}