public class Driver{
    public static void main(String[]args){
       Human h1 = new Human();
//       h1.ageNao(40);
       h1.ageNao(-5);
       System.out.println(h1.ageDao());
    }
}