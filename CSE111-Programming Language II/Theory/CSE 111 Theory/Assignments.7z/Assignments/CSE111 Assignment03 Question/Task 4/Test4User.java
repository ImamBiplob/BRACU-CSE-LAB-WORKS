public class Test4User {
    public static void main(String[] args) {
        Test4 t = new Test4();
        t.methodA();
    }
}