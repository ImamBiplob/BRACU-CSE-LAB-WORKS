public class TestUser {
    public static void main(String[] args) {
        Test t = new Test();
        t.methodA();
        t.methodB();
    }
}