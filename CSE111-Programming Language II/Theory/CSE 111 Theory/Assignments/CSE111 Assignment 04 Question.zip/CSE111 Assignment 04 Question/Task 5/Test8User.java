public class Test8User {
    public static void main(String[] args){
        Test8 t8 = new Test8();
        t8.methodA();
        t8.methodB(6,8);
    }
}