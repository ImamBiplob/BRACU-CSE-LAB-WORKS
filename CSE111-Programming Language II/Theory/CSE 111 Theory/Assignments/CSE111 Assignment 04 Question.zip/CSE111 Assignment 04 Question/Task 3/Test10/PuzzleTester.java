class PuzzleTester{
    public static void main(String[]args)
{
        Puzzle p = new Puzzle();
        p.methodA();
        p.methodA();
      }
}
/*
10 5
10 18
30 20
30 63
31 64
30 63
10 5
10 18
30 20
30 63
31 64
30 63
10 5
10 18
30 20
30 63
31 64
30 63
37 7

*/
